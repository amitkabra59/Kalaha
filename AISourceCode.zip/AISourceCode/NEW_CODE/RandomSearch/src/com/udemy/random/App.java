package com.udemy.random;

public class App {

	public static void main(String[] args) {
		
		StochasticSearch search = new StochasticSearch();
		search.stochasticSearch();
		
	}
}
