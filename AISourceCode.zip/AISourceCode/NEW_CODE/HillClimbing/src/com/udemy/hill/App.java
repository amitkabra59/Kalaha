package com.udemy.hill;

public class App {

	public static void main(String[] args) {
		
		HillClimbing climbing = new HillClimbing();
		climbing.hillClimning();
		
	}
}
