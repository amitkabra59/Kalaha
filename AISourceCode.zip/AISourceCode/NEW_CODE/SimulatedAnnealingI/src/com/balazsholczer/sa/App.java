package com.balazsholczer.sa;

public class App {

	public static void main(String[] args) {
		
		SimulatedAnnealing annealing = new SimulatedAnnealing();
		annealing.findOptimum();
		
	}
}
