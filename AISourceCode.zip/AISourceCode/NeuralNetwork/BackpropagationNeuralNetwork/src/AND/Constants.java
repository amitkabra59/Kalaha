package AND;

public class Constants {

	private Constants(){
		
	}
	
	public static final int NUM_OF_FEATURES = 2;
	public static final int NUM_OF_DATA = 4;
	public static final double LEARNING_RATE = 0.1;
	public static final int THREASHOLD = 1;
	
}
