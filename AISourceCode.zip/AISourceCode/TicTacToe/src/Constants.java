
public class Constants {

	private Constants(){
		
	}
	
	public static final int BOARD_SIZE = 3;
	
}
