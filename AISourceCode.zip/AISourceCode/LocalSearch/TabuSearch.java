package com.balazsholczer.max;

import java.util.List;

public class TabuSearch {
	
	public static double f(double x){
		return -(x*x);
	}
	
	public static void main(String[] args) {
		
		double s = f(-2);
		double sBest = s;
		List<Double> tabuList;
		double dx = 0.1;
		
		for(int i=0;i<100;i++){
			
			List<Double> candidateList;
			double bestCandidate;
			
			if( !tabuList.contains(arg0))
			
		}
		
	}
}
